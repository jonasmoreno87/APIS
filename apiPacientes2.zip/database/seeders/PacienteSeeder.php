<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class PacienteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    { 
        DB::table('pacientes')->insert([
        [
            'nombres' => 'Jhonatan',
            'apellidos' => 'Moreno Sánchez',
            'edad' => 34,
            'sexo' => 'Masculino',
            'dni' => 70218511,
            'tipo_sangre' => 'O+',
            'telefono' => 543124351,
            'correo' => 'jms@gmail.com',
            'direccion' => 'Crra 64D # 111-15',
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s'),

        ],

        [
            'nombres' => 'José Andrés',
            'apellidos' => 'Moncada Restrepo',
            'edad' => 33,
            'sexo' => 'Masculino',
            'dni' => 70118552,
            'tipo_sangre' => 'A+',
            'telefono' => 2264351,
            'correo' => 'monca@gmail.com',
            'direccion' => 'Crra 88 # 64-15',
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s'), 

        ],
        [
            'nombres' => 'Josue Alberto',
            'apellidos' => 'Alvarez Ardila',
            'edad' => 25,
            'sexo' => 'Masculino',
            'dni' => 10171851,
            'tipo_sangre' => 'O+',
            'telefono' => 4414351,
            'correo' => 'ardi@gmail.com',
            'direccion' => 'Clle 33B # 45-15',
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s'),
        ],
        [
            'nombres' => 'Mario Idalgo',
            'apellidos' => 'Cuerbo Nieto',
            'edad' => 18,
            'sexo' => 'Masculino',
            'dni' => 80218511,
            'tipo_sangre' => 'B+',
            'telefono' => 932112351,
            'correo' => 'mario@gmail.com',
            'direccion' => 'Jr. Manuel Ruiz 800',
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s'),
        ],
        [
            'nombres' => 'Valeria',
            'apellidos' => 'Duque Nieto',
            'edad' => 9,
            'sexo' => 'Femenino',
            'dni' => 10258886,
            'tipo_sangre' => 'B+',
            'telefono' => 5042514,
            'correo' => 'vale@gmail.com',
            'direccion' => 'Urb la Pastora Apto 102',
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s'),
        ]
        ]);
    }
}
